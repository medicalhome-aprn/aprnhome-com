<?php
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
// SCHLIX WEB CONTENT MANAGEMENT SYSTEM - Copyright (C) SCHLIX WEB INC.
// This is a SHARED SOURCE, NOT OPEN SOURCE (GPL).
// You may use this software commercially, but you are not allowed to create a fork or create a derivative of this software
// Please read the license for details
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
if (!defined('SCHLIX_VERSION'))
    die('No Access');

global $CurrentUser;
?>

<div id="<?= $this->block_name; ?>" class="frontpage-latestblog <?= $this->css_class_div ?>">
    <h3 class="frontpage-latestblog-category-title"><?= $block_title; ?></h3>
    <?php for ($i = 0; $i < $max_entries; $i++): ?>
        <?php
        $item = $items[$i];
        $entry = $item['date_created'];
        // you can customize your own stuff here
        $link = $blog->createFriendlyURL("action=viewitem&id={$item['id']}");
        $entrydate = date("j.M.Y", strtotime($item['date_created']));
        $entrytitle = $item['title'];
        /* <li><?= $entrydate; ?><br /><a href="<?= $link; ?>"><?= SAFE_HTML($entrytitle); ?></a></li> */

        $secondary_headline = $item['summary_secondary_headline'] ? $item['summary_secondary_headline'] : mb_substr(strip_tags($item['summary']), 0, 255,'UTF-8') . '...';
        if ($item['summary_secondary_headline']) {
            $secondary_headline = $item['summary_secondary_headline'];
        } else {
            $article_summary = strip_tags($item['summary']);
            $max_string_length = 100;
            $article_summary_space_position = mb_strpos($article_summary, ' ', $max_string_length-5);
            if ($article_summary_space_position == 0 || $article_summary_space_position > $max_string_length)
                $article_summary_space_position = $max_string_length;
            $secondary_headline = mb_substr($article_summary, 0, $article_summary_space_position,'UTF-8');
        }

        $thumb_filename = $item['summary_intro_image'] ? $blog->getDataFileURLPath('image_small', $item['summary_intro_image']) : '';
        ?> 
        <?php if ($item['status'] == 1 && $CurrentUser->hasReadPermission($item['permission_read']) && ( $item['date_expiry'] == '0000-00-00 00:00:00' || days_difference_from_today($item['date_expiry']) > 0 )): ?>
            <h4 class="intro-title"><a href="<?= $link ?>"><?= SAFE_HTML($entrytitle) ?></a></h4>
            <span class="intro-date"><?= $entrydate ?></span>
            <div class="row">
                <!-- col -->
                <?php if ($thumb_filename): ?>

                    <div class="col-xs-5 col-sm-12 col-md-5 intro-image">
                        <!-- intro image -->
                            <a href="<?= $link ?>"><img class="intro-image thumbnail" src="<?= $thumb_filename ?>" alt="<?= SAFE_HTML($item['summary_intro_image_caption']) ?>)"></a>
                        <!-- end intro image -->

                    </div>
                <?php endif ?>
                <!-- col -->
                <!-- end col -->
                <div class="col-xs-<?= $thumb_filename ? '7' : '12' ?> col-sm-12 col-md-<?= $thumb_filename ? '7' : '12' ?> intro-text">
                    <?= $secondary_headline ?>
                    
                </div>     
                <!-- end col -->
                
            </div>        


    <?php endif; ?>
    <?php endfor; ?>
</div>