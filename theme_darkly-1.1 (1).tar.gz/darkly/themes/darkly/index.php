<?php if (!defined('SCHLIX_VERSION')) die('No Access'); ?>
<?php
/**
 * Darkly - theme
 * 
 * Bootswatch Darkly theme http://bootswatch.com/darkly/ originally made by Thomas Park.
 * 
 * @copyright SCHLIX Web Inc
 *
 * @license MIT
 *
 * @package darkly
 * @version 1.0
 * @author  SCHLIX Web Inc <info@schlix.com>
 * @link    https://www.schlix.com
 */
?>
<!doctype html>
<head>
    <meta charset="UTF-8">
    <title><?= SCHLIX_SITE_NAME; ?> - <?= SCHLIX\cmsPageOutput::HTMLPageTitle() ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="<?= CURRENT_THEME_URL_PATH; ?>/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="<?= CURRENT_THEME_URL_PATH; ?>/css/bootstrap-submenu.css" />
    <link rel="stylesheet" type="text/css" href="<?= SCHLIX_SYSTEM_URL_PATH ?>/fonts/font-awesome/font-awesome.min.css" />
    <link rel="stylesheet" type="text/css" href="<?= CURRENT_THEME_URL_PATH; ?>/css/style.css" />
    <meta name="description" content="<?= SCHLIX\cmsPageOutput::HTMLMetaDescription() ?>" />
    <meta name="keywords" content="<?= SCHLIX\cmsPageOutput::HTMLMetaKeywords() ?>" />
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
    <link rel="shortcut icon" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/favicon.ico" type="image/x-icon" />
    <link rel="apple-touch-icon" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon.png" />
    <link rel="apple-touch-icon" sizes="57x57" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-57x57.png" />
    <link rel="apple-touch-icon" sizes="72x72" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-72x72.png" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-76x76.png" />
    <link rel="apple-touch-icon" sizes="114x114" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-114x114.png" />
    <link rel="apple-touch-icon" sizes="120x120" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-120x120.png" />
    <link rel="apple-touch-icon" sizes="144x144" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-144x144.png" />
    <link rel="apple-touch-icon" sizes="152x152" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-152x152.png" />
    <link rel="apple-touch-icon" sizes="180x180" href="<?= CURRENT_THEME_URL_PATH; ?>/icons/apple-touch-icon-180x180.png" />
    <script src="<?= SCHLIX_SYSTEM_URL_PATH; ?>/js/jquery/jquery-2.2.4.min.js"></script>
    <script src="<?= SCHLIX_SYSTEM_URL_PATH; ?>/js/bootstrap/3/bootstrap.min.js"></script>
    <script src="<?= SCHLIX_SYSTEM_URL_PATH; ?>/js/bootstrap/3/bootstrap-submenu.js"></script>
    <script src="<?= CURRENT_THEME_URL_PATH; ?>/js/main.js"></script>
    <?= SCHLIX\cmsPageOutput::HTMLHeader(); ?>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-inverse" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
                <a class="navbar-brand" href="<?= SCHLIX_SITE_HTTPBASE.'/' ?>"><?= SCHLIX_SITE_NAME ?></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse pull-right" id="bs-example-navbar-collapse-1">
                <?= SCHLIX\cmsPageOutput::BlockCategory('menu_top'); ?>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <section id="display-page">
        <div class="container">
             <?= SCHLIX\cmsPageOutput::BreadCrumbs(); ?>
 
            <?= SCHLIX\cmsPageOutput::ApplicationBody() ?>
        </div>
    </section><!--/#error-->

    <section id="bottom" >
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <?= SCHLIX\cmsPageOutput::BlockCategory('footer1') ?>
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <?= SCHLIX\cmsPageOutput::BlockCategory('footer2') ?>
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                       <?= SCHLIX\cmsPageOutput::BlockCategory('footer3') ?>
                    </div>    
                </div><!--/.col-md-3-->

                <div class="col-md-3 col-sm-6">
                    <div class="widget">
                        <?= SCHLIX\cmsPageOutput::BlockCategory('footer4') ?>
                    </div>    
                </div><!--/.col-md-3-->
            </div>
        </div>
    </section>


    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 copyright">
                    &copy; <?= date('Y') ?> <a target="_blank" href="<?= SCHLIX_SITE_URL ?>" title="Demo theme">My Company Name</a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <?= SCHLIX\cmsPageOutput::BlockCategory('menu_bottom') ?>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <!-- end body -->
</body>
</html> 