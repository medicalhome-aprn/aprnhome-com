/**
 * Darkly - theme class
 * 
 * Bootswatch Darkly theme http://bootswatch.com/darkly/ originally made by Thomas Park.
 * 
 * @copyright SCHLIX Web Inc
 *
 * @license MIT
 *
 * @package darkly
 * @version 1.0
 * @author  SCHLIX Web Inc <info@schlix.com>
 * @link    https://www.schlix.com
 */

// Bootstrap 3 does not allow submenu level greater than 2 by default. This 
// is the patch
$(document).ready(function(){
	
  $('.dropdown-submenu > a ').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});