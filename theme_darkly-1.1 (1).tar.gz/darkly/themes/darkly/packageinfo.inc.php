<?php

$name = 'Darkly';
$type = 'theme';
$guid = '4b199282-3c16-d364-f947-c3151c37ae1f';
$version = '1.1';
$license = 'MIT';
$description = 'Bootswatch Darkly theme http://bootswatch.com/darkly/ originally made by Thomas Park.';
$author = 'SCHLIX Web Inc';
$url = 'https://www.schlix.com';
$email = 'info@schlix.com';
$copyright = 'Copyright &copy;SCHLIX Web Inc';